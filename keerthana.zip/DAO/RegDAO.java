package com.niit.DAO;
import java.util.List;
import com.niit.Model.RegModel;
public interface RegDAO {
	void addRegModel(RegModel s);
	void delRegModel(int sid);
	void updRegModel(RegModel s);
	RegModel viewRegModelById(int sid);
	List<RegModel> viewAllRegModels();
}

