package com.niit.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import com.niit.DAO.RegDAO;
import com.niit.Model.RegModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Controller
public class BaseController {
	@Autowired
	RegDAO sd;
	@Autowired
	RegDAO sd1;
	/*@RequestMapping("/")
	public String gouserprofile() {
	System.out.println("index");
	return "index";
	}*/
	@ModelAttribute("staffobj")
	public RegModel getRegModel(){
		return new RegModel();
	}
	@RequestMapping("/")
	public String goregistration() {
	System.out.println("registration");
	return "registration";
	}
	@RequestMapping("/save")
	public String goSave(@ModelAttribute("staffobj")RegModel x){
		sd.addRegModel(x);
		return "registration";
	}
	@RequestMapping("/view")
	public ModelAndView viewUser(){
		ModelAndView m = new ModelAndView("viewUser");
		m.addObject("data", sd.viewAllRegModels());
		return m;
	}
}