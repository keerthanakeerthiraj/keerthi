package com.niit.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.validation.BindingResult;
import com.niit.DAO.*;
import com.niit.Model.*;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;


@Controller
public class BaseController {
	@Autowired
	RegDAO sd;
	@Autowired
	ProdDAO pd;
	@Autowired
	AddDAO ad;
	@Autowired
	BillDAO bd;
	ModelAndView m;
	/*@RequestMapping("/")
	public String gouserprofile() {
	System.out.println("index");
	return "womens";
	}*/
	@ModelAttribute("staffobj")
	public RegModel getRegModel(){
		return new RegModel();
	}
	@ModelAttribute("productobj")
	public ProModel getProModel(){
		return new ProModel();
	}
	@ModelAttribute("addressobj")
	public AddModel getAddModel(){
		return new AddModel();
	}
	@ModelAttribute("Billobj")
	public AddModel getBillModel(){
		return new AddModel();
	}
	@RequestMapping("/")
	public String gorindex() {
	System.out.println("index");
	return "index";
	}
	
	@RequestMapping("/login")
	public String gorlogin() {
	System.out.println("login");
	return "login";
	}	
	@RequestMapping("/save")
	public ModelAndView addC(@Valid @ModelAttribute("staffobj")RegModel x,BindingResult br){
		if(br.hasErrors()){
			m= new ModelAndView("registration");
			
			m.addObject("staffobj", x);
			return m;
		}
				
			m = new ModelAndView("login");
			
			 String emailregex = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*(\\.[A-Za-z]{2,})$";
			 if(x.getPass().equals(x.getRepass())&&x.getEmail().matches(emailregex))
			 {
				 sd.addRegModel(x);
			 }
			 else
			 {
				 m= new ModelAndView("registration");
			     m.addObject("staffobj", x);
				return m; 
			 }		
			return m;
		}

	@RequestMapping("/add")
	public String goSave(@ModelAttribute("productobj")ProModel x1, HttpServletRequest req){
		pd.addProModel(x1);

		MultipartFile  itemImage = x1.getFile();
        String rootDirectory =
req.getSession().getServletContext().getRealPath("/");
        File f = new File(rootDirectory + "resources\\images\\");
        if(!f.exists())
        f.mkdirs();
        Path path = Paths.get(rootDirectory +"resources\\images\\"+x1.getPid()+".jpg");

        if (itemImage != null && !itemImage.isEmpty()) {
            try {
            itemImage.transferTo(new File(path.toString()));
            System.out.println("Image Uploaded - "+rootDirectory +"resources\\images\\"+x1.getPid()+".jpg");
            } catch (Exception e) {            	
                e.printStackTrace();
                throw new RuntimeException("item image saving failed.", e);
            }
        }
		return "redirect:/adprod";
	}
	@RequestMapping("/store")
	public String goSore(@ModelAttribute("addressobj")AddModel x2){ 
		ad.addAddModel(x2);
		return "address";
	}
	@RequestMapping("/billstore")
	public String goSore(@ModelAttribute("billobj")BillModel x4){ 
		bd.addBillModel(x4);
		return "billaddress";
	}
	@RequestMapping("/view")
	public ModelAndView viewUser(){
		ModelAndView m = new ModelAndView("viewUser");
		m.addObject("data", sd.viewAllRegModels());
		return m;
	}
	@RequestMapping("/adprod")
	public String goprod() {
	System.out.println("adprod");
	return "adprod";
	}
	@RequestMapping("/address")
	public String goaddress() {
	System.out.println("address");
	return "address";
	}
	@RequestMapping("/billaddress")
	public String gobilladdress() {
	System.out.println("billaddress");
	return "billaddress";
	}
	
	@RequestMapping("/about")
	public String goabout() {
	System.out.println("about");
	return "about";
	}
	
	@RequestMapping("/blog")
	public String blog() {
	System.out.println("blog");
	return "blog";
	}
	@RequestMapping("/cart")
	public String gocart() {
	System.out.println("cart");
	return "cart";
	}
	@RequestMapping("/contact")
	public String gocontact() {
	System.out.println("contact");
	return "contact";
	}
	
	@RequestMapping("/editproduct")
	public String goeditproduct() {
	System.out.println("editproduct");
	return "editproduct";
	}
	
	@RequestMapping("/index")
	public String gologin() {
	System.out.println("index");
	return "index";
	}
	
	@RequestMapping("/menu")
	public String gomenu() {
	System.out.println("menu");
	return "menu";
	}
	@RequestMapping("/products")
	public String goproducts() {
	System.out.println("products");
	return "products";
	}
	@RequestMapping("/shop")
	public String goshop() {
	System.out.println("shop");
	return "shop";
	}
	@RequestMapping("/single")
	public String gosingle() {
	System.out.println("single");
	return "single";
	}
	@RequestMapping("/womens")
	public String gowomens() {
	System.out.println("womens");
	return "womens";
	}
	@RequestMapping("/registration")
	public String goregistration() {
	System.out.println("registration");
	return "registration";
	}
	@RequestMapping("/mens")
	public String gomens() {
	System.out.println("mens");
	return "mens";
	}
	@RequestMapping("/viewallproducts")
	public ModelAndView goviewproducts() {
	System.out.println("viewallproduct");
   ModelAndView view=new ModelAndView("viewallproducts");
	view.addObject("data", pd.viewAllProModels());	
	return view;
	}
	@RequestMapping("/viewpd/{id}")
	public ModelAndView goviewproduct(@PathVariable("id")int id) {
	System.out.println(id);
	ModelAndView view=new ModelAndView("viewproducts");
	view.addObject("data", pd.viewProModelById(id));	
	return view;
	}
	 @RequestMapping("/logout")
 	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response){
 	ModelAndView view = new ModelAndView("index");
 	request.getSession().invalidate();
 	return view;
 	} 
  
	/*  @RequestMapping(value="/login", method=RequestMethod.GET)
	public String showlogin(@RequestParam String email, ModelMap model) {
	model.put("name",email);

	return "welcome"; 
	} */
}