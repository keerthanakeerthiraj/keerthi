package com.niit.Model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
@Entity
public class RegModel {
	@Id
	@Email
	@NotEmpty(message="enter a valid e mail id")
	private String email;
	@Column
	@NotEmpty(message="enter a Name")
	private String fname;
	@Column
	@NotEmpty
	private String lname ;
	@Column
	@NotEmpty(message="enter a Password")
	private String pass ;
	@Column
	@NotEmpty(message="password not valid")
	private String repass ;
	@Column
	@NotEmpty(message="enter a number")
	private String number ;
	@Column
	private String role="ROLE_USER";
	@Column
	private boolean enabled=true; 
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getRepass() {
		return repass;
	}
	public void setRepass(String repass) {
		this.repass = repass;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
}
