package com.niit.DAO;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.niit.Model.RegModel;

@Repository
public class RegDAOImpl implements RegDAO {
	@Autowired
	SessionFactory sf;
	
	Session ss;
	Transaction t;

	@Override
	public void addRegModel(RegModel s) {
		ss = sf.openSession();
		t = ss.beginTransaction();
		ss.save(s);
		t.commit();
	}

	@Override
	public void delRegModel(String email) {
		ss = sf.openSession();
		t = ss.beginTransaction();
		RegModel x = (RegModel)ss.load(RegModel.class,email);
		ss.delete(x);
		t.commit();
	}

	@Override
	public void updRegModel(RegModel s) {
		ss = sf.openSession();
		t = ss.beginTransaction();
		RegModel x = (RegModel)ss.load(RegModel.class,s.getEmail());
		x.setFname(s.getFname());
		x.setLname(s.getLname());
		x.setEmail(s.getEmail());
		x.setPass(s.getPass());
		x.setRepass(s.getRepass());
		x.setNumber(s.getNumber());
		ss.saveOrUpdate(x);
		t.commit();
	
	}

	@Override
	public RegModel viewRegModelById(String email) {
		// TODO Auto-generated method stub
		ss = sf.openSession();
		t = ss.beginTransaction();
		RegModel x = (RegModel)ss.load(RegModel.class,email);
		t.commit();
		return x;

	}

	@Override
	public List<RegModel> viewAllRegModels() {
		// TODO Auto-generated method stub
		ss = sf.openSession();
		t = ss.beginTransaction();
		List<RegModel> l = ss.createCriteria(RegModel.class).list();
		t.commit();
		return l;
	
	}

}
