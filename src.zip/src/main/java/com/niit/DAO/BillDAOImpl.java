package com.niit.DAO;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.niit.Model.BillModel;
@Repository
public class BillDAOImpl implements BillDAO {
	@Autowired
	SessionFactory sf3;
	
	Session ss3;
	Transaction t4;
	@Override
	public void addBillModel(BillModel s3) {
		// TODO Auto-generated method stub
		ss3 = sf3.openSession();
		t4 = ss3.beginTransaction();
		ss3.save(s3);
		t4.commit();
	}

	@Override
	public void delBillModel(int aid) {
		// TODO Auto-generated method stub

	}

	@Override
	public void updBillModel(BillModel s3) {
		// TODO Auto-generated method stub

	}

	@Override
	public BillModel viewBillModelById(int aid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<BillModel> viewAllBillModels() {
		// TODO Auto-generated method stub
		return null;
	}

}
