package com.niit.DAO;
import java.util.List;
import com.niit.Model.RegModel;
public interface RegDAO {
	void addRegModel(RegModel s);
	void delRegModel(String email);
	void updRegModel(RegModel s);
	RegModel viewRegModelById(String email);
	List<RegModel> viewAllRegModels();
}

	