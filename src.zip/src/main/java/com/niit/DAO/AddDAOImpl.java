package com.niit.DAO;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import com.niit.Model.AddModel;
import com.niit.Model.ProModel;
@Repository
public class AddDAOImpl implements AddDAO {
	@Autowired
	SessionFactory sf2;
	
	Session ss2;
	Transaction t3;

	@Override
	public void addAddModel(AddModel s2) {
		// TODO Auto-generated method stub
		ss2 = sf2.openSession();
		t3 = ss2.beginTransaction();
		ss2.save(s2);
		t3.commit();
	}

	@Override
	public void delAddModel(int aid) {
		// TODO Auto-generated method stub
		ss2 = sf2.openSession();
		t3 = ss2.beginTransaction();
		AddModel x3 = (AddModel)ss2.load(AddModel.class,aid);
		ss2.delete(x3);
		t3.commit();
	}

	@Override
	public void updAddModel(AddModel s2) {
		// TODO Auto-generated method stub
		ss2 = sf2.openSession();
		t3 = ss2.beginTransaction();
		AddModel x3 = (AddModel)ss2.load(AddModel.class,s2.getAid());
		x3.setName(s2.getName());
		x3.setPno(s2.getPno());
		x3.setPcode(s2.getPcode());
		x3.setCity(s2.getCity());
		x3.setArea(s2.getArea());
		x3.setAddress(s2.getAddress());
		x3.setLandmark(s2.getLandmark());
		x3.setApno(s2.getApno());
		ss2.saveOrUpdate(x3);
		t3.commit();

	}

	@Override
	public AddModel viewAddModelById(int aid) {
		// TODO Auto-generated method stub
		ss2 = sf2.openSession();
		t3 = ss2.beginTransaction();
		AddModel x3 = (AddModel)ss2.load(AddModel.class,aid);
		t3.commit();
		return x3;
	}

	@Override
	public List<AddModel> viewAllAddModels() {
		// TODO Auto-generated method stub
		ss2 = sf2.openSession();
		t3 = ss2.beginTransaction();
		List<AddModel> l2 = ss2.createCriteria(AddModel.class).list();
		t3.commit();
		return l2;
	}

}
