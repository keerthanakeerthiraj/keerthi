package com.niit.DAO;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.niit.Model.ProModel;

@Repository
public class ProModelImpl implements ProdDAO {
	@Autowired
	SessionFactory sf1;
	
	Session ss1;
	Transaction t1;

	@Override
	public void addProModel(ProModel s1) {
		// TODO Auto-generated method stub
		ss1 = sf1.openSession();
		t1 = ss1.beginTransaction();
		ss1.save(s1);
		t1.commit();
	}

	@Override
	public void delProModel(int pid) {
		// TODO Auto-generated method stub
		ss1 = sf1.openSession();
		t1 = ss1.beginTransaction();
		ProModel x1 = (ProModel)ss1.load(ProModel.class,pid);
		ss1.delete(x1);
		t1.commit();
	}

	@Override
	public void updProModel(ProModel s1) {
		// TODO Auto-generated method stub
		ss1 = sf1.openSession();
		t1 = ss1.beginTransaction();
		ProModel x1 = (ProModel)ss1.load(ProModel.class,s1.getPid());
		x1.setPname(s1.getPname());
		x1.setPrice(s1.getPrice());
		x1.setQty(s1.getQty());
		x1.setDec(s1.getDec());
		ss1.saveOrUpdate(x1);
		t1.commit();


	}

	@Override
	public ProModel viewProModelById(int pid) {
		// TODO Auto-generated method stub

		ss1 = sf1.openSession();
		t1 = ss1.beginTransaction();
		ProModel x1 = (ProModel)ss1.load(ProModel.class,pid);
		t1.commit();
		return x1;
	}

	@Override
	public List<ProModel> viewAllProModels() {
		// TODO Auto-generated method stub
		ss1 = sf1.openSession();
		t1 = ss1.beginTransaction();
		List<ProModel> l1 = ss1.createCriteria(ProModel.class).list();
		t1.commit();
		return l1;
	
	}

}
