package com.niit.DAO;

import java.util.List;

import com.niit.Model.ProModel;

public interface ProdDAO {
	void addProModel(ProModel s1);
	void delProModel(int pid);
	void updProModel(ProModel s1);
	ProModel viewProModelById(int pid);
	List<ProModel> viewAllProModels();
}
