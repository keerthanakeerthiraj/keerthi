package com.niit.DAO;
import java.util.List;
import com.niit.Model.BillModel;
public interface BillDAO {
	void addBillModel(BillModel s3);
	void delBillModel(int aid);
	void updBillModel(BillModel s3);
	BillModel viewBillModelById(int aid);
	List<BillModel> viewAllBillModels();
}
